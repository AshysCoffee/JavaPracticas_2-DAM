package practfinal_java_io;

public enum Cargo {VENDEDOR, ENCARGADO

}
