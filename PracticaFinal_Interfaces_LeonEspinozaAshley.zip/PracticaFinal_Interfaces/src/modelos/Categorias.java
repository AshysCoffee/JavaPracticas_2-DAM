package modelos;

public enum Categorias {
	ECONOMIA,
    DEPORTES,
    NACIONAL,
    INTERNACIONAL,
    CIENCIAS,
    FAUNA
}
