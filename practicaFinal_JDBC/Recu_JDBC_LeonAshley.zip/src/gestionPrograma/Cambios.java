package gestionPrograma;

import java.sql.Connection;
import java.util.List;

import modelosBases.Cambio;
import modelosBases.Stock;
import queriesJDBC.GestionCambios;
import queriesJDBC.GestionStocks;

public class Cambios {

	private Connection conexion;
	private GestionCambios gc;
	private GestionStocks gs;

	public Cambios(Connection conexion) {
		this.conexion = conexion;
		this.gc = new GestionCambios(conexion);
		this.gs = new GestionStocks(conexion);
		System.out.println("Conexión recibida en Consultas.");
	}

	public Connection getConexion() {
		return conexion;
	}

	public void setConexion(Connection conexion) {
		this.conexion = conexion;
	}

	

	public boolean ingresarCambio(String motivo, int stand_id_original, int zona_id_original,
	        int juguete_id_original, int stand_id_nuevo, int zona_id_nuevo, int juguete_id_nuevo, int empleado_id) {

	    if (motivo == null || motivo.isEmpty()) {
	        System.out.println("Tiene que rellenar este espacio");
	        return false;
	    }

	    if (stand_id_original <= 0 || zona_id_original <= 0 || juguete_id_original <= 0 || stand_id_nuevo <= 0
	            || zona_id_nuevo <= 0 || juguete_id_nuevo <= 0) {
	        System.out.println("Los IDs no pueden ser negativos ni cero");
	        return false;
	    }

	    if (empleado_id <= 0) {
	        System.out.println("El ID del empleado tiene que ser positivo");
	        return false;
	    }

	    Stock stockOriginal = gs.obtenerStockdelStand(stand_id_original, zona_id_original, juguete_id_original);

	    if (stockOriginal == null) {
	        System.out.println("El stock original no existe. Intentando crearlo...");
	        Stock nuevoStock = new Stock(stand_id_original, zona_id_original, juguete_id_original, 0);
	        
	        boolean stockCreado = gs.insertarStock(nuevoStock);

	        if (!stockCreado) {
	            System.err.println("Error: No se pudo crear el Stock Original. Probablemente el Juguete o Stand indicados no existen.");
	            return false;
	        }
	        stockOriginal = nuevoStock;
	    }

	    Stock stockNuevo = gs.obtenerStockdelStand(stand_id_nuevo, zona_id_nuevo, juguete_id_nuevo);
	    
	    if (stockNuevo == null || stockNuevo.getCantidad_disponible() < 1) {
	        System.err.println("Error: No hay stock disponible del producto nuevo para entregar.");
	        return false;
	    }

	    gs.actualizarStock(stand_id_nuevo, zona_id_nuevo, juguete_id_nuevo, stockNuevo.getCantidad_disponible() - 1);
	    
	    gs.actualizarStock(stand_id_original, zona_id_original, juguete_id_original, stockOriginal.getCantidad_disponible() + 1);

	    Cambio cambio = new Cambio(
	            motivo, 
	            empleado_id,           
	            juguete_id_original,   
	            juguete_id_nuevo, 
	            stand_id_original, 
	            zona_id_original, 
	            stand_id_nuevo, 
	            zona_id_nuevo
	    );

	    boolean cambiado = gc.insertarCambio(cambio);

	    return cambiado;
	}

	public void listasTodosCambios() {

		List<Cambio> cambiosAll = gc.obtenerTodosLosCambios();

		if (cambiosAll == null || cambiosAll.isEmpty()) {
			System.out.println("No hay juguetes en ese rango.");
		} else {

			for (Cambio c : cambiosAll) {
				System.out.println(c);
			}

		}

	}

	public Cambio buscarCambio(int id) {

		if (id <= 0) {
			System.out.println("EL ID no puede ser negativo");
			return null;
		}

		Cambio buscado = gc.obtenerCambioPorId(id);

		if (buscado == null) {
			System.err.println("El cambio con ID " + id + " no existe.");
			return null;
		} else {
			System.out.println("Cambio encontrado: " + buscado);
			return buscado;
		}

	}

	public void listasCambiosPerEmpleados(int empleado) {

		if (empleado <= 0) {
			System.out.println("EL ID no puede ser negativo");
			return;
		}

		List<Cambio> cambiosEmpleado = gc.obtenerCambiosPorEmpleado(empleado);

		if (cambiosEmpleado == null || cambiosEmpleado.isEmpty()) {
			System.out.println("Este empleado no tiene ventas con su ID");
		} else {

			for (Cambio c : cambiosEmpleado) {
				System.out.println(c);
			}

		}

	}

}
