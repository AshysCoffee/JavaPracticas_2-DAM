/**
 * 
 */
/**
 * 
 */
module practicaFinal_JDBC {
	requires java.sql;
}