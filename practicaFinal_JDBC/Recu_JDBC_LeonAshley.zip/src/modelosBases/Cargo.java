package modelosBases;

public enum Cargo {
	JEFE, CAJERO;
}
