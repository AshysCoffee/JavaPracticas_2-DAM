package modelosBases;

public enum TipoPago {
	EFECTIVO, TARJETA, PAYPAL
}
