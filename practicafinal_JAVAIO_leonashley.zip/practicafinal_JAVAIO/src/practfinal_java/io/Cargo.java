package practfinal_java.io;

public enum Cargo {VENDEDOR, ENCARGADO

}
